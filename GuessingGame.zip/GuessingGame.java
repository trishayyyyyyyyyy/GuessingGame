import java.util.Random;
import java.util.Scanner;

public class GuessingGame {

    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);

        int randomNumber = rand.nextInt(100)+ 1;

int count = 0 ;
while(true) {
    System.out.println(" Enter your guess (1-100):");

    int playerGuess = scanner.nextInt();
    count++;

    if (playerGuess == randomNumber) {
        System.out.println(" Welldone! correct guess");
       System.out.println("your number of tries is " + count);
        break;
    } else if (randomNumber > playerGuess) {
        System.out.println("Ooops to high! try again ");
    } else {
        System.out.println("Oops to low, try again!");
    }
       }
scanner.close();
    }
}